using UnityEngine;

public static class SimulationReferenceResolver
{
    public static Transform ResolveBucketRopeAttachment(
        Transform bucket,
        Transform currentAttachment)
    {
        if (currentAttachment != null)
        {
            return currentAttachment;
        }

        if (bucket == null)
        {
            return null;
        }

        Transform generatedAttachment = bucket.Find("Generated_RopeAttachmentPoint");

        if (generatedAttachment != null)
        {
            return generatedAttachment;
        }

        RealisticBucketVisualBuilder visualBuilder =
            bucket.GetComponent<RealisticBucketVisualBuilder>();

        if (visualBuilder != null && visualBuilder.RopeAttachmentPoint != null)
        {
            return visualBuilder.RopeAttachmentPoint;
        }

        return null;
    }
}